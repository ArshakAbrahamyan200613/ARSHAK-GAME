var socket = io();

var side = 10;
function setup() {
    createCanvas(50 * side, 50 * side);
    background("red");
}
var weath
socket.on("weather", function (data) {
    weath = data;
})

function nkarel(matrix) {
    for (var y = 0; y < matrix.length; y++) {
        for (var x = 0; x < matrix[0].length; x++) {
            var obj = matrix[y][x];
            if (obj == 1) {
                if (weath == "summer") {
                    fill("green");
                } else if (weath == "autumn") {
                    fill("#333300");
                } else if (weath == "winter") {
                    fill("white");
                } else if (weath == "spring") {
                    fill("#4dffa6");
                }
            } else if (obj == 2) {
                if (weath == "summer") {
                    fill("##B5B69F");
                } else if (weath == "autumn") {
                    fill("#cc00ff");
                } else if (weath == "winter") {
                    fill("#0066cc");
                } else if (weath == "spring") {
                    fill("FFA600");
                }
            } else if (obj == 0) {
                fill("gray")
            }
            else if (obj == 3) {
                if (weath == "summer") {
                    fill("#FFA600");
                } else if (weath == "autumn") {
                    fill("#F4FF0C");
                } else if (weath == "winter") {
                    fill("#B5B69F");
                } else if (weath == "spring") {
                    fill("#4dffa6");
                }
            }
            else if (obj == 4) {
                if (weath == "summer") {
                    fill("black");
                } else if (weath == "autumn") {
                    fill("#e38e05");
                } else if (weath == "winter") {
                    fill("#e38e05");
                } else if (weath == "spring") {
                    fill("#F7BF56");
                }

            }
            else if (obj == 5) {
                fill("red");
            } else if (obj == 0) {
                fill("grey")
            }


            rect(x * side, y * side, side, side);
        }
    }
}

socket.on('send matrix', nkarel)



function kill() {
    socket.emit("kill")
}
function addGrass() {
    socket.emit("add grass")
}
function addGrassEater() {
    socket.emit("add grassEater")
}
function addPredator() {
    socket.emit("add predator")
}
function addVorsord() {
    socket.emit("add vorsord")
}
function Armagedon() {
    socket.emit("Armagedon")
}
